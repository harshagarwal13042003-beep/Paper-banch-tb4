"""Independent scalar state model; never imports the candidate package."""
from __future__ import annotations

import json
from pathlib import Path

import pyarrow.parquet as pq

from cases import digest, encode


def expected_generation(job_path, parent=None, *, input_root=None):
    path = Path(job_path).resolve()
    root = path.parent
    job = json.loads(path.read_text(encoding="utf-8"))
    schemas = dict(parent["schemas"]) if parent is not None else {}
    schemas[str(job["schema"]["id"])] = job["schema"]["fields"]

    def active(old, removed, added):
        removed_set = set(removed)
        return [item for item in old if item["path"] not in removed_set] + list(added)

    data = active(parent["data_files"] if parent else [],
                  job["remove_data"], job["add_data"])
    deletes = active(parent["delete_files"] if parent else [],
                     job["remove_deletes"], job["add_deletes"])
    data_hashes = [digest((root / item["path"]).read_bytes()) for item in data]
    delete_hashes = [digest((root / item["path"]).read_bytes()) for item in deletes]
    parent_hash = digest(encode(parent) + b"\n") if parent is not None else None
    identity = digest(encode({"job": job, "parent_snapshot_sha256": parent_hash,
                              "data_sha256": data_hashes,
                              "delete_sha256": delete_hashes}))

    file_lookup = {item["path"]: item for item in data}
    source_rows = {}
    for item in data:
        fields = schemas[str(item["schema_id"])]
        physical = pq.read_table(root / item["path"], use_threads=False).to_pylist()
        source_rows[item["path"]] = [
            {field["id"]: row[field["name"]] for field in fields}
            for row in physical
        ]
    removed_positions = {item["path"]: set() for item in data}
    eligible_delete = {item["path"]: False for item in deletes}
    for item in deletes:
        for record in pq.read_table(root / item["path"], use_threads=False).to_pylist():
            source = file_lookup[record["file_path"]]
            if item["sequence"] >= source["sequence"]:
                removed_positions[source["path"]].add(record["pos"])
                eligible_delete[item["path"]] = True

    current = job["schema"]["fields"]
    partitions = sorted({item["partition"] for item in data + deletes})
    by_partition = {}
    shard_meta = []
    all_rows = []
    for partition in partitions:
        rows = []
        lineage = []
        for item in data:
            if item["partition"] != partition:
                continue
            source = source_rows[item["path"]]
            skipped = removed_positions[item["path"]]
            for position, original in enumerate(source):
                if position in skipped:
                    continue
                row = {}
                for field in current:
                    value = original.get(field["id"], field["default"])
                    if value is not None and field["type"] == "float64":
                        value = float(value)
                    row[field["name"]] = value
                rows.append(row)
            lineage.append({"data_file": item["path"], "input_rows": len(source),
                            "deleted_rows": len(skipped),
                            "retained_rows": len(source) - len(skipped)})
        by_partition[partition] = rows
        all_rows.extend(rows)
        shard_meta.append({
            "partition": partition,
            "path": f"shards/{identity}/part-{partition}.parquet",
            "row_count": len(rows), "row_digest": digest(encode(rows)),
            "lineage": lineage,
            "delete_files": [item["path"] for item in deletes
                             if item["partition"] == partition and eligible_delete[item["path"]]],
        })
    snapshot = {
        "version": 1, "generation": job["generation"],
        "snapshot_id": job["snapshot_id"], "identity": identity,
        "parent_identity": job["parent_identity"],
        "input_root": str(root) if input_root is None else str(input_root),
        "schemas": schemas, "current_schema_id": job["schema"]["id"],
        "data_files": data, "delete_files": deletes, "fields": current,
        "shards": shard_meta, "total_rows": len(all_rows),
        "total_row_digest": digest(encode(all_rows)),
    }
    return snapshot, by_partition


def expected_catalog(snapshot):
    return {"version": 1, "generation": snapshot["generation"],
            "identity": snapshot["identity"],
            "snapshot_path": f"snapshots/{snapshot['identity']}.json",
            "snapshot_sha256": digest(encode(snapshot) + b"\n")}


def expected_journal(snapshot, catalog_path, action):
    shards = snapshot["shards"][:min(action, len(snapshot["shards"]))]
    body = {"version": 1, "identity": snapshot["identity"],
            "parent_identity": snapshot["parent_identity"],
            "generation": snapshot["generation"],
            "catalog_path": str(Path(catalog_path).resolve()),
            "next_action": action, "shards": shards,
            "total_rows": sum(item["row_count"] for item in shards)}
    return {**body, "checksum": digest(encode(body))}
