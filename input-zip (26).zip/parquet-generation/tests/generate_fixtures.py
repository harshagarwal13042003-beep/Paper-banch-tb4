"""Local authoring helper: generate matched public and protected input histories."""
from pathlib import Path

from cases import make_history, set_parent
from oracle import expected_generation


def build(root, *, input_root, seed=0):
    jobs = make_history(root, seed=seed)
    first, _ = expected_generation(jobs[0], input_root=input_root)
    set_parent(jobs[1], first["identity"])
    second, _ = expected_generation(jobs[1], first, input_root=input_root)
    set_parent(jobs[2], second["identity"])
    expected_generation(jobs[2], second, input_root=input_root)


if __name__ == "__main__":
    task = Path(__file__).resolve().parents[1]
    build(task / "tests" / "fixtures" / "sample", input_root="/tests/fixtures/sample")
    build(task / "environment" / "data" / "input", input_root="/app/input")
