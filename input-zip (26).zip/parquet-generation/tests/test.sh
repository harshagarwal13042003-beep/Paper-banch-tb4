#!/bin/sh
set -eu
umask 022
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TARGET=${1:-"/app/workspace/compactor"}
REPORT_DIR=${2:-"/logs/verifier"}
mkdir -p "$REPORT_DIR"
chmod 0700 "$REPORT_DIR"
rm -f "$REPORT_DIR/reward.txt" "$REPORT_DIR/ctrf.json"
exec python "$SCRIPT_DIR/test_outputs.py" --target "$TARGET" --report-dir "$REPORT_DIR"
