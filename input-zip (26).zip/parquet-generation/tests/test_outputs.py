"""Protected, outcome-based verifier for generation-aware Parquet compaction.

The oracle and reward stay in this root-owned process. Candidate imports and
CLI calls run only in separate UID 20000 processes with no verifier access.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import traceback

import pyarrow.parquet as pq

from cases import DELETE_SCHEMA, F1, digest, encode, field_schema, make_history, set_parent, write_table
from oracle import expected_catalog, expected_generation, expected_journal


CANDIDATE_UID = 20000
DRIVER = Path("/opt/tb-candidate/candidate_driver.py")
if not DRIVER.is_file():
    DRIVER = Path(__file__).resolve().with_name("candidate_driver.py")


def stage_target(source, root):
    source = Path(source)
    assert source.is_dir() and (source / "__init__.py").is_file(), "missing candidate package"
    assert not any(part.is_symlink() for part in (source, *source.parents)), "candidate path symlink"
    destination = root / "candidate" / "compactor"
    destination.mkdir(parents=True, mode=0o755)
    folders = [destination]
    for member in sorted(source.rglob("*")):
        assert not member.is_symlink(), "candidate symlink"
        target = destination / member.relative_to(source)
        if member.is_dir():
            target.mkdir(mode=0o755)
            folders.append(target)
        elif member.is_file():
            shutil.copyfile(member, target)
            target.chmod(0o444)
        else:
            raise AssertionError("candidate special member")
    for folder in reversed(folders):
        folder.chmod(0o555)
    destination.parent.chmod(0o555)
    return destination


def drop_identity():
    os.setgroups([])
    os.setgid(CANDIDATE_UID)
    os.setuid(CANDIDATE_UID)


def child_env(target):
    return {"PATH": os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin"),
            "PYTHONPATH": str(target.parent), "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONUNBUFFERED": "1", "HOME": "/tmp"}


def candidate_request(target, request):
    process = subprocess.run(
        [sys.executable, str(DRIVER), str(target)], input=json.dumps(request),
        text=True, capture_output=True, timeout=90, cwd="/tmp",
        env=child_env(target), preexec_fn=drop_identity,
    )
    assert process.returncode == 0, f"candidate process failed: {process.stderr[-500:]}"
    try:
        reply = json.loads(process.stdout)
    except ValueError as exc:
        raise AssertionError("invalid candidate protocol") from exc
    assert type(reply) is dict and type(reply.get("ok")) is bool, "invalid driver reply"
    return reply


def api(target, input_path, catalog, journal, *, stop=None, resume=False):
    request = {"mode": "api", "input": str(input_path), "catalog": str(catalog),
               "journal": str(journal), "stop_after_actions": stop, "resume": resume}
    reply = candidate_request(target, request)
    if not reply["ok"]:
        if reply.get("error") == "ValueError":
            raise ValueError(reply.get("message", "invalid candidate input"))
        raise AssertionError(f"candidate raised {reply.get('error')}: {reply.get('message')}")
    return reply["value"]


def cli(target, mode, input_path, catalog, journal, stop=None):
    command = [sys.executable, "-m", "compactor", mode,
               "--input", str(input_path), "--catalog", str(catalog),
               "--journal", str(journal)]
    if stop is not None:
        command += ["--stop-after-actions", str(stop)]
    return subprocess.run(command, text=True, capture_output=True, timeout=90,
                          cwd="/tmp", env=child_env(target), preexec_fn=drop_identity)


def case_paths(root, name):
    case = root / name
    case.mkdir(mode=0o755)
    output, state = case / "output", case / "state"
    output.mkdir(mode=0o777)
    state.mkdir(mode=0o777)
    output.chmod(0o777)
    state.chmod(0o777)
    return case, output / "catalog.json", state / "journal.json"


def validate_shard(path, fields, rows):
    table = pq.read_table(path, use_threads=False)
    wanted = field_schema(fields)
    assert len(table.schema) == len(wanted), (path, "column count")
    for actual, expected in zip(table.schema, wanted):
        assert actual.equals(expected, check_metadata=True), (path, actual, expected)
    assert table.to_pylist() == rows, (path, "rows differ")


def validate_complete(catalog, journal, result, expected, rows):
    wanted_catalog = expected_catalog(expected)
    wanted_journal = expected_journal(expected, catalog, len(expected["shards"]) + 2)
    assert result == {"status": "complete", "journal": wanted_journal,
                      "catalog": wanted_catalog, "snapshot": expected}, "API result differs"
    assert catalog.read_bytes() == encode(wanted_catalog) + b"\n", "catalog bytes differ"
    snapshot_file = catalog.parent / wanted_catalog["snapshot_path"]
    assert snapshot_file.read_bytes() == encode(expected) + b"\n", "snapshot bytes differ"
    assert journal.read_bytes() == encode(wanted_journal) + b"\n", "journal bytes differ"
    for shard in expected["shards"]:
        validate_shard(catalog.parent / shard["path"], expected["fields"],
                       rows[shard["partition"]])


def immutable_bytes(catalog):
    published = json.loads(catalog.read_text(encoding="utf-8"))
    snapshot_file = catalog.parent / published["snapshot_path"]
    snapshot = json.loads(snapshot_file.read_text(encoding="utf-8"))
    paths = [snapshot_file] + [catalog.parent / item["path"] for item in snapshot["shards"]]
    return {str(path): path.read_bytes() for path in paths}


def assert_preserved(before):
    for name, data in before.items():
        assert Path(name).read_bytes() == data, f"prior immutable object changed: {name}"


def validate_partial(catalog, journal, result, expected, rows, action, old_catalog=None):
    wanted = expected_journal(expected, catalog, action)
    assert result == {"status": "incomplete", "journal": wanted}, "partial return differs"
    assert journal.read_bytes() == encode(wanted) + b"\n", "partial journal bytes differ"
    if old_catalog is None:
        assert not catalog.exists(), "catalog published early"
    else:
        assert catalog.read_bytes() == old_catalog, "catalog changed before final action"
    count = len(expected["shards"])
    if 1 <= action <= count:
        for shard in expected["shards"][:action]:
            name = f"part-{shard['partition']}.parquet"
            path = catalog.parent / ".staging" / expected["identity"] / name
            validate_shard(path, expected["fields"], rows[shard["partition"]])
    if action == count + 1:
        for shard in expected["shards"]:
            validate_shard(catalog.parent / shard["path"], expected["fields"],
                           rows[shard["partition"]])


def check_histories(target, root):
    for seed in (0, 7, 29):
        case, catalog, _ = case_paths(root, f"history-{seed}")
        jobs = make_history(case / "input", seed=seed)
        parent = None
        protected = {}
        for generation, job in enumerate(jobs, 1):
            if parent is not None:
                set_parent(job, parent["identity"])
            expected, rows = expected_generation(job, parent)
            journal = case / "state" / f"g{generation}.json"
            result = api(target, job, catalog, journal)
            validate_complete(catalog, journal, result, expected, rows)
            assert_preserved(protected)
            protected.update(immutable_bytes(catalog))
            parent = expected
        assert parent["generation"] == 3
        assert any(row["label"] == "fresh" for shard_rows in rows.values()
                   for row in shard_rows), "field-ID name-reuse fixture is ineffective"


def check_boundaries(target, root):
    for generation in (1, 2):
        probe, _, _ = case_paths(root, f"boundary-probe-{generation}")
        probe_jobs = make_history(probe / "input", seed=41 + generation)
        p1, _ = expected_generation(probe_jobs[0])
        if generation == 2:
            set_parent(probe_jobs[1], p1["identity"])
            expected, _ = expected_generation(probe_jobs[1], p1)
        else:
            expected = p1
        count = len(expected["shards"])
        for action in range(count + 2):
            case, catalog, _ = case_paths(root, f"boundary-{generation}-{action}")
            jobs = make_history(case / "input", seed=41 + generation)
            old_catalog = None
            parent = None
            if generation == 2:
                first, first_rows = expected_generation(jobs[0])
                g1_journal = case / "state" / "g1.json"
                result = api(target, jobs[0], catalog, g1_journal)
                validate_complete(catalog, g1_journal, result, first, first_rows)
                old_catalog = catalog.read_bytes()
                parent = first
                set_parent(jobs[1], parent["identity"])
            job = jobs[generation - 1]
            expected, rows = expected_generation(job, parent)
            journal = case / "state" / f"g{generation}.json"
            partial = api(target, job, catalog, journal, stop=action)
            validate_partial(catalog, journal, partial, expected, rows, action, old_catalog)
            repeated = api(target, job, catalog, journal, stop=0, resume=True)
            validate_partial(catalog, journal, repeated, expected, rows, action, old_catalog)
            final = api(target, job, catalog, journal, resume=True)
            validate_complete(catalog, journal, final, expected, rows)
            again = api(target, job, catalog, journal, resume=True)
            validate_complete(catalog, journal, again, expected, rows)
            if generation == 2:
                assert (catalog.parent / expected_catalog(parent)["snapshot_path"]).is_file()


def check_one_action_resumes(target, root):
    case, catalog, _ = case_paths(root, "one-action")
    job = make_history(case / "input", seed=53)[0]
    expected, rows = expected_generation(job)
    journal = case / "state" / "g1.json"
    result = api(target, job, catalog, journal, stop=0)
    validate_partial(catalog, journal, result, expected, rows, 0)
    for action in range(1, len(expected["shards"]) + 2):
        result = api(target, job, catalog, journal, stop=1, resume=True)
        validate_partial(catalog, journal, result, expected, rows, action)
    final = api(target, job, catalog, journal, stop=1, resume=True)
    validate_complete(catalog, journal, final, expected, rows)


def check_stale_worker(target, root):
    case, catalog, _ = case_paths(root, "stale-worker")
    g1, g2, _ = make_history(case / "input", seed=61)
    first, first_rows = expected_generation(g1)
    j1 = case / "state" / "g1.json"
    validate_complete(catalog, j1, api(target, g1, catalog, j1), first, first_rows)
    set_parent(g2, first["identity"])
    second, second_rows = expected_generation(g2, first)
    ja = case / "state" / "g2a.json"
    old = catalog.read_bytes()
    stopped = api(target, g2, catalog, ja, stop=len(second["shards"]) + 1)
    validate_partial(catalog, ja, stopped, second, second_rows,
                     len(second["shards"]) + 1, old)
    b = json.loads(g2.read_text(encoding="utf-8"))
    b["snapshot_id"] = "competing-valid-generation"
    other = g2.parent / "g2b.json"
    other.write_bytes(encode(b) + b"\n")
    other_expected, other_rows = expected_generation(other, first)
    jb = case / "state" / "g2b.json"
    completed = api(target, other, catalog, jb)
    validate_complete(catalog, jb, completed, other_expected, other_rows)
    live = catalog.read_bytes()
    protected = immutable_bytes(catalog)
    stale_journal = ja.read_bytes()
    for stale_job, stale_file in ((g2, ja), (g1, j1)):
        try:
            api(target, stale_job, catalog, stale_file, resume=True)
        except ValueError:
            pass
        else:
            raise AssertionError("stale worker accepted")
    assert catalog.read_bytes() == live and ja.read_bytes() == stale_journal
    assert_preserved(protected)
    again = api(target, other, catalog, jb, resume=True)
    validate_complete(catalog, jb, again, other_expected, other_rows)


def check_journal_tamper(target, root):
    case, catalog, _ = case_paths(root, "journal-tamper")
    job = make_history(case / "input", seed=73)[0]
    expected, rows = expected_generation(job)
    journal = case / "state" / "g1.json"
    api(target, job, catalog, journal, stop=1)
    original = journal.read_bytes()
    changed = json.loads(original)
    changed["total_rows"] += 1
    body = {key: value for key, value in changed.items() if key != "checksum"}
    changed["checksum"] = digest(encode(body))
    journal.write_bytes(encode(changed) + b"\n")
    bad = journal.read_bytes()
    try:
        api(target, job, catalog, journal, resume=True)
    except ValueError:
        pass
    else:
        raise AssertionError("semantic journal tamper accepted")
    assert journal.read_bytes() == bad and not catalog.exists()
    journal.write_bytes(original)
    shard = expected["shards"][0]
    staged = catalog.parent / ".staging" / expected["identity"]
    write_table(staged, f"part-{shard['partition']}.parquet", [],
                field_schema(expected["fields"]))
    try:
        api(target, job, catalog, journal, resume=True)
    except ValueError:
        pass
    else:
        raise AssertionError("altered staged shard accepted")
    assert journal.read_bytes() == original and not catalog.exists()


def check_parent_source_tamper(target, root):
    case, catalog, _ = case_paths(root, "parent-source-tamper")
    g1, g2, _ = make_history(case / "input", seed=79)
    first, first_rows = expected_generation(g1)
    j1 = case / "state" / "g1.json"
    validate_complete(catalog, j1, api(target, g1, catalog, j1), first, first_rows)
    set_parent(g2, first["identity"])
    j2 = case / "state" / "g2.json"
    api(target, g2, catalog, j2, stop=0)
    protected = immutable_bytes(catalog)
    live = catalog.read_bytes()
    source = g2.parent / first["data_files"][0]["path"]
    source.write_bytes(source.read_bytes() + b"tampered")
    try:
        api(target, g2, catalog, j2, resume=True)
    except ValueError:
        pass
    else:
        raise AssertionError("mutated active input accepted")
    assert catalog.read_bytes() == live
    assert_preserved(protected)


def check_invalid_inputs(target, root):
    def attempt(label, mutate, *, raw=None):
        case, catalog, journal = case_paths(root, f"bad-{label}")
        job = make_history(case / "input", seed=83)[0]
        if raw is not None:
            job.write_bytes(raw(job.read_bytes()))
        else:
            value = json.loads(job.read_text(encoding="utf-8"))
            mutate(value, job.parent)
            job.write_bytes(encode(value) + b"\n")
        try:
            api(target, job, catalog, journal)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid input accepted: " + label)
        assert not catalog.exists() and not journal.exists(), "invalid input published state"

    attempt("duplicate-key", None,
            raw=lambda b: b.replace(b'"version":1', b'"version":1,"version":1', 1))
    attempt("malformed", None, raw=lambda _: b'{"version":')
    attempt("bool-generation", lambda j, _: j.__setitem__("generation", True))
    attempt("bool-count", lambda j, _: j["add_data"][0].__setitem__("row_count", False))
    attempt("overflow", lambda j, _: j["add_data"][0].__setitem__("row_count", 1 << 63))
    attempt("duplicate-path", lambda j, _: j["add_data"].append(dict(j["add_data"][0])))
    attempt("wrong-digest", lambda j, _: j["add_data"][0].__setitem__("sha256", "0" * 64))
    attempt("traversal", lambda j, _: j["add_data"][0].__setitem__("path", "data/a/../old.parquet"))
    attempt("bad-delete", lambda j, p: _bad_delete(j, p))
    attempt("field-id", lambda j, p: _bad_field_id(j, p))
    attempt("symlink", lambda j, p: _symlink_data(j, p))
    case, catalog, journal = case_paths(root, "bad-path-collision")
    job = make_history(case / "input", seed=89)[0]
    for a, b in ((job, catalog), (catalog, catalog)):
        try:
            api(target, job, a, b)
        except ValueError:
            pass
        else:
            raise AssertionError("path collision accepted")


def _bad_delete(job, root):
    item = job["add_deletes"][0]
    rows = pq.read_table(root / item["path"], use_threads=False).to_pylist()
    rows[0]["file_path"] = "data/missing.parquet"
    item["sha256"] = write_table(root, item["path"], rows, DELETE_SCHEMA)


def _bad_field_id(job, root):
    item = job["add_data"][0]
    rows = pq.read_table(root / item["path"], use_threads=False).to_pylist()
    altered = copy.deepcopy(F1)
    altered[0]["id"] = 99
    item["sha256"] = write_table(root, item["path"], rows, field_schema(altered))


def _symlink_data(job, root):
    item = job["add_data"][0]
    link = root / "data" / "a" / "linked.parquet"
    link.symlink_to(root / item["path"])
    item["path"] = "data/a/linked.parquet"


def check_cli(target, root):
    case, catalog, journal = case_paths(root, "cli")
    job = make_history(case / "input", seed=97)[0]
    expected, rows = expected_generation(job)
    stopped = cli(target, "run", job, catalog, journal, stop=1)
    assert stopped.returncode == 0, stopped.stderr
    wanted = {"status": "incomplete", "journal": expected_journal(expected, catalog, 1)}
    assert stopped.stdout.encode() == encode(wanted) + b"\n", "CLI partial stdout"
    assert not catalog.exists()
    completed = cli(target, "resume", job, catalog, journal)
    assert completed.returncode == 0, completed.stderr
    wanted_final = {"status": "complete", "journal": expected_journal(
        expected, catalog, len(expected["shards"]) + 2),
        "catalog": expected_catalog(expected), "snapshot": expected}
    assert completed.stdout.encode() == encode(wanted_final) + b"\n", "CLI final stdout"
    validate_complete(catalog, journal, wanted_final, expected, rows)
    before = catalog.read_bytes()
    bad = cli(target, "run", job, catalog, catalog)
    assert bad.returncode != 0 and catalog.read_bytes() == before, "CLI collision changed catalog"
    missing = case / "output" / "missing.json"
    bad2 = cli(target, "run", job, missing, missing)
    assert bad2.returncode != 0 and not missing.exists(), "CLI collision created output"


def check_declared_artifact(catalog, journal):
    fixture = Path(__file__).parent / "fixtures" / "sample" / "g1.json"
    expected, rows = expected_generation(fixture, input_root="/app/input")
    wanted = {"status": "complete",
              "journal": expected_journal(expected, catalog, len(expected["shards"]) + 2),
              "catalog": expected_catalog(expected), "snapshot": expected}
    validate_complete(catalog, journal, wanted, expected, rows)


def check_isolation_controls(root):
    if Path("/tests/oracle.py").exists():
        probe = subprocess.run([sys.executable, "-c",
            "import os,sys; sys.exit(0 if "
            "not os.access('/tests/oracle.py',os.R_OK) and "
            "not os.access('/logs/verifier',os.R_OK|os.X_OK) else 1)"],
            cwd="/tmp", env={"PATH": "/usr/local/bin:/usr/bin:/bin"},
            preexec_fn=drop_identity, capture_output=True, text=True, timeout=10)
        assert probe.returncode == 0, "candidate can inspect protected verifier or reward"
    source = root / "malicious-source"
    source.mkdir(mode=0o755)
    (source / "__init__.py").write_text(
        "import sys\n"
        "m=sys.modules.get('test_outputs')\n"
        "if m is not None: m.check_histories=lambda *a: None\n"
        "def run_generation(*a, **k): return {'status':'complete'}\n",
        encoding="utf-8")
    source.chmod(0o755)
    evil = stage_target(source, root / "evil-staging")
    assert candidate_request(evil, {"mode": "import"}) == {"ok": True, "value": None}
    case, catalog, journal = case_paths(root, "evil-control")
    job = make_history(case / "input", seed=101)[0]
    expected, rows = expected_generation(job)
    try:
        validate_complete(catalog, journal, api(evil, job, catalog, journal), expected, rows)
    except (AssertionError, FileNotFoundError):
        pass
    else:
        raise AssertionError("empty malicious implementation received credit")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", required=True)
    parser.add_argument("--report-dir", required=True)
    parser.add_argument("--artifact", default="/app/output/catalog.json")
    parser.add_argument("--journal-artifact", default="/app/state/g1.json")
    args = parser.parse_args()
    target = Path(args.target).absolute()
    report = Path(args.report_dir)
    report.mkdir(parents=True, exist_ok=True)
    results = []
    checks = [check_histories, check_boundaries, check_one_action_resumes,
              check_stale_worker, check_journal_tamper,
              check_parent_source_tamper, check_invalid_inputs, check_cli]
    with tempfile.TemporaryDirectory(prefix="parquet-generation-verifier-") as temporary:
        root = Path(temporary)
        root.chmod(0o755)
        try:
            check_isolation_controls(root)
            results.append(("isolation_controls", True, ""))
        except Exception:
            results.append(("isolation_controls", False, traceback.format_exc()))
        try:
            staged = stage_target(target, root)
            reply = candidate_request(staged, {"mode": "import"})
            assert reply == {"ok": True, "value": None}, reply
            results.append(("import_public_api", True, ""))
        except Exception:
            staged = None
            results.append(("import_public_api", False, traceback.format_exc()))
        if staged is not None:
            for check in checks:
                try:
                    check(staged, root)
                    results.append((check.__name__, True, ""))
                except Exception:
                    results.append((check.__name__, False, traceback.format_exc()))
        try:
            check_declared_artifact(Path(args.artifact), Path(args.journal_artifact))
            results.append(("declared_artifact", True, ""))
        except Exception:
            results.append(("declared_artifact", False, traceback.format_exc()))
    success = bool(results) and all(ok for _, ok, _ in results)
    ctrf = {"results": {"tool": {"name": "parquet-generation-verifier"},
                        "summary": {"tests": len(results),
                                    "passed": sum(ok for _, ok, _ in results),
                                    "failed": sum(not ok for _, ok, _ in results),
                                    "skipped": 0, "pending": 0, "other": 0},
                        "tests": [{"name": name, "status": "passed" if ok else "failed",
                                   "message": detail} for name, ok, detail in results]}}
    (report / "ctrf.json").write_bytes(encode(ctrf) + b"\n")
    (report / "reward.txt").write_text("1\n" if success else "0\n", encoding="utf-8")
    for name, ok, detail in results:
        print(("PASS " if ok else "FAIL ") + name)
        if detail:
            print(detail)
    return 0 if success else 1


if __name__ == "__main__":
    raise SystemExit(main())
