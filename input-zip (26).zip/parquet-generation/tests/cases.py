"""Deterministic input histories for the independent verifier."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def digest(data):
    return hashlib.sha256(data).hexdigest()


F1 = [
    {"id": 1, "name": "id", "type": "int64", "nullable": False, "default": 0},
    {"id": 2, "name": "score", "type": "float64", "nullable": True, "default": None},
    {"id": 3, "name": "label", "type": "string", "nullable": True, "default": "legacy"},
]
F2 = [
    {"id": 1, "name": "entity_id", "type": "int64", "nullable": False, "default": 0},
    {"id": 2, "name": "score", "type": "float64", "nullable": True, "default": None},
    {"id": 3, "name": "label", "type": "string", "nullable": True, "default": "legacy"},
    {"id": 4, "name": "new_metric", "type": "int64", "nullable": True, "default": 7},
]
F3 = [
    {"id": 1, "name": "entity_id", "type": "int64", "nullable": False, "default": 0},
    {"id": 2, "name": "score", "type": "float64", "nullable": True, "default": None},
    {"id": 4, "name": "new_metric", "type": "int64", "nullable": True, "default": 7},
    {"id": 5, "name": "label", "type": "string", "nullable": False, "default": "fresh"},
]


def field_schema(fields):
    types = {"int64": pa.int64(), "float64": pa.float64(), "string": pa.string()}
    return pa.schema([pa.field(f["name"], types[f["type"]], nullable=f["nullable"],
                               metadata={b"PARQUET:field_id": str(f["id"]).encode()})
                      for f in fields])


DELETE_SCHEMA = pa.schema([pa.field("file_path", pa.string(), nullable=False),
                           pa.field("pos", pa.int64(), nullable=False)])


def write_table(root, relative, rows, schema):
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    pq.write_table(pa.Table.from_pylist(rows, schema=schema), path,
                   use_dictionary=False, version="2.6")
    return digest(path.read_bytes())


def entry(root, path, partition, sequence, rows, schema, *, schema_id=None):
    value = {"path": path, "partition": partition, "sequence": sequence,
             "row_count": len(rows), "sha256": write_table(root, path, rows, schema)}
    if schema_id is not None:
        value["schema_id"] = schema_id
    return value


def job_file(root, name, generation, snapshot_id, parent, schema, rd, ad, rz, az):
    value = {"version": 1, "generation": generation, "snapshot_id": snapshot_id,
             "parent_identity": parent, "schema": schema,
             "remove_data": rd, "add_data": ad,
             "remove_deletes": rz, "add_deletes": az}
    path = root / name
    path.write_bytes(encode(value) + b"\n")
    return path


def make_history(root, seed=0, parent1=None, parent2=None):
    """Create three related jobs; later parent identities can be patched after each run."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    a0 = entry(root, "data/a/old.parquet", "A", 0,
               [{"id": seed + 10, "score": 1.5, "label": "left"},
                {"id": seed + 11, "score": 2.5, "label": "middle"},
                {"id": seed + 12, "score": 3.5, "label": "right"}], field_schema(F1), schema_id=1)
    b0 = entry(root, "data/b/old.parquet", "B", 2,
               [{"id": seed + 20, "score": 4.5, "label": "b0"},
                {"id": seed + 21, "score": 5.5, "label": "b1"}], field_schema(F1), schema_id=1)
    e0 = entry(root, "data/e/empty.parquet", "E", 0, [], field_schema(F1), schema_id=1)
    da0 = entry(root, "deletes/a/first.parquet", "A", 0,
                [{"file_path": a0["path"], "pos": 1},
                 {"file_path": a0["path"], "pos": 1}], DELETE_SCHEMA)
    db0 = entry(root, "deletes/b/early.parquet", "B", 1,
                [{"file_path": b0["path"], "pos": 0}], DELETE_SCHEMA)
    dd0 = entry(root, "deletes/d/empty.parquet", "D", 0, [], DELETE_SCHEMA)
    g1 = job_file(root, "g1.json", 1, f"g1-{seed}", None,
                  {"id": 1, "fields": F1}, [], [a0, b0, e0], [], [da0, db0, dd0])

    a1 = entry(root, "data/a/new.parquet", "A", 2,
               [{"entity_id": seed + 30, "score": 6.5, "label": "new0", "new_metric": 9},
                {"entity_id": seed + 31, "score": None, "label": "new1", "new_metric": None}],
               field_schema(F2), schema_id=2)
    b1 = entry(root, "data/b/new.parquet", "B", 3,
               [{"entity_id": seed + 40, "score": 7.5, "label": "newb", "new_metric": 10}],
               field_schema(F2), schema_id=2)
    da1 = entry(root, "deletes/a/second.parquet", "A", 2,
                [{"file_path": a0["path"], "pos": 0},
                 {"file_path": a1["path"], "pos": 1}], DELETE_SCHEMA)
    db1 = entry(root, "deletes/b/second.parquet", "B", 2,
                [{"file_path": b0["path"], "pos": 1},
                 {"file_path": b1["path"], "pos": 0}], DELETE_SCHEMA)
    g2 = job_file(root, "g2.json", 2, f"g2-{seed}", parent1,
                  {"id": 2, "fields": F2}, [e0["path"]], [a1, b1],
                  [da0["path"]], [da1, db1])

    a2 = entry(root, "data/a/latest.parquet", "A", 4,
               [{"entity_id": seed + 50, "score": 8.5, "new_metric": 11,
                 "label": "current"}], field_schema(F3), schema_id=3)
    c2 = entry(root, "data/c/latest.parquet", "C", 4,
               [{"entity_id": seed + 60, "score": 9.5, "new_metric": 12,
                 "label": "c"}], field_schema(F3), schema_id=3)
    db2 = entry(root, "deletes/b/latest.parquet", "B", 4,
                [{"file_path": b1["path"], "pos": 0}], DELETE_SCHEMA)
    g3 = job_file(root, "g3.json", 3, f"g3-{seed}", parent2,
                  {"id": 3, "fields": F3}, [a0["path"]], [a2, c2],
                  [da1["path"], db1["path"]], [db2])
    return [g1, g2, g3]


def set_parent(path, identity):
    job = json.loads(Path(path).read_text(encoding="utf-8"))
    job["parent_identity"] = identity
    Path(path).write_bytes(encode(job) + b"\n")
