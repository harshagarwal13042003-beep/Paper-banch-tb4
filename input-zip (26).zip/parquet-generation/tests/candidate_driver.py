"""Unprivileged adapter. This module contains no verifier or reward logic."""
from __future__ import annotations

import contextlib
import importlib
import io
import json
from pathlib import Path
import sys


def execute(request, target):
    sys.path.insert(0, str(target.parent))
    package = importlib.import_module("compactor")
    if request["mode"] == "import":
        if not callable(package.run_generation):
            raise AssertionError("missing public API")
        return None
    if request["mode"] != "api":
        raise AssertionError("unknown driver mode")
    return package.run_generation(
        request["input"], request["catalog"], request["journal"],
        stop_after_actions=request.get("stop_after_actions"),
        resume=request.get("resume", False),
    )


def main():
    target = Path(sys.argv[1]).absolute()
    request = json.load(sys.stdin)
    with contextlib.redirect_stdout(io.StringIO()):
        try:
            answer = {"ok": True, "value": execute(request, target)}
        except BaseException as exc:
            answer = {"ok": False, "error": type(exc).__name__, "message": str(exc)}
    sys.stdout.write(json.dumps(answer, ensure_ascii=False, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
