# Generation-aware Parquet compaction repair

This is a **new local task prototype** with its own public contract. It does not replace the frozen, Stage-1-passing Parquet v3 package. No platform submission or Stage-2/Stage-3 result is claimed for this prototype.

The agent image contains a faulty but usable starter, the public instruction, and sample input. The verifier image contains protected tests and an independent scalar oracle; the reference solution is separate. Candidate code is exercised from an unprivileged process and cannot read verifier code or reward files.

The operational scenario is a local Parquet table that is compacted repeatedly while source files and delete files change. A later generation may rename a field without changing its ID, remove a data file, retain another file written against an older schema, and receive position deletes with different sequence numbers. An interrupted worker has a durable journal; another worker may commit a newer snapshot before it resumes. The repair must keep the catalog pointing at a complete generation throughout these transitions.

## Difficulty explanation

The repair requires coherent behavior across generations, not just a correct final table. It must validate inherited active files and immutable parent snapshots, evolve schemas by field ID, apply sequence-aware position deletes, maintain deterministic per-partition lineage, validate every journal prefix, and prevent a stale worker from replacing a newer catalog. Each part interacts with the others: a projection bug can survive row-count checks, while a correct shard can still be associated with the wrong parent or published too early.

## Solution explanation

The reference checks the job and all active Parquet bytes before publication, resolves parent-linked file deltas, projects surviving rows by stable field ID, stages one shard per partition, and records durable progress. Resume revalidates input identity, parent, journal checksum, and staged objects. The immutable snapshot is installed before the catalog pointer, which is replaced only after its dependencies exist.

## Verification explanation

The independent oracle compares decoded Parquet rows and field IDs, ordered lineage, canonical JSON, and generation history. Tests cover delete sequence ties, rename and name reuse, removals, empty partitions, interruption at every documented durable boundary, repeated resume, stale-worker conflicts, journal tampering, API/CLI behavior, and validation failures that preserve published output. Local reference reward 1 and NOP reward 0 are required before release; neither proves platform admission or long-horizon outcome.

## Relevant experience

Python data engineering, Parquet and Arrow schemas, lakehouse-style snapshot catalogs, position deletes, deterministic serialization, and recovery protocols.
