"""Contract test suite for generation-aware Parquet compaction.

Execute: python -m unittest /app/workspace/tests/verify_compactor.py
"""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

import pyarrow.parquet as pq


def canonical_json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


class CompactorContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, "/app/workspace")
        from compactor import run_generation
        cls.run_generation = staticmethod(run_generation)
        cls.input_dir = Path("/app/input")

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="compactor_test_"))
        self.catalog = self.tmp / "output" / "catalog.json"
        self.journal_g1 = self.tmp / "state" / "g1.json"
        self.journal_g2 = self.tmp / "state" / "g2.json"
        self.journal_g3 = self.tmp / "state" / "g3.json"

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_01_public_api_callable(self):
        self.assertTrue(callable(self.run_generation), "run_generation must be callable")

    def test_02_g1_full_run(self):
        g1_input = self.input_dir / "g1.json"
        result = self.run_generation(g1_input, self.catalog, self.journal_g1)
        self.assertEqual(result.get("status"), "complete")
        self.assertTrue(self.catalog.is_file(), "Catalog must exist after generation 1")
        cat_data = json.loads(self.catalog.read_text(encoding="utf-8"))
        self.assertEqual(cat_data.get("generation"), 1)
        self.assertIn("identity", cat_data)
        snap_file = self.catalog.parent / cat_data["snapshot_path"]
        self.assertTrue(snap_file.is_file(), "Snapshot file must exist")
        snap_data = json.loads(snap_file.read_text(encoding="utf-8"))
        self.assertEqual(snap_data.get("total_rows"), 4)
        self.assertEqual(len(snap_data.get("shards", [])), 4)

    def test_03_g2_schema_evolution_and_deletes(self):
        g1_input = self.input_dir / "g1.json"
        g2_input = self.input_dir / "g2.json"
        self.run_generation(g1_input, self.catalog, self.journal_g1)
        result = self.run_generation(g2_input, self.catalog, self.journal_g2)
        self.assertEqual(result.get("status"), "complete")
        cat_data = json.loads(self.catalog.read_text(encoding="utf-8"))
        self.assertEqual(cat_data.get("generation"), 2)
        snap_file = self.catalog.parent / cat_data["snapshot_path"]
        snap_data = json.loads(snap_file.read_text(encoding="utf-8"))
        self.assertEqual(snap_data.get("current_schema_id"), 2)
        # Verify partition B shard has projected schema with field tag
        b_shard = self.catalog.parent / f"shards/{cat_data['identity']}/part-B.parquet"
        self.assertTrue(b_shard.is_file())
        table = pq.read_table(b_shard)
        field_names = table.column_names
        self.assertIn("new_metric", field_names)
        self.assertIn("entity_id", field_names)

    def test_04_g3_parent_linkage(self):
        self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1)
        r2 = self.run_generation(self.input_dir / "g2.json", self.catalog, self.journal_g2)
        g2_ident = r2["catalog"]["identity"]
        r3 = self.run_generation(self.input_dir / "g3.json", self.catalog, self.journal_g3)
        self.assertEqual(r3.get("status"), "complete")
        self.assertEqual(r3["snapshot"]["parent_identity"], g2_ident)
        self.assertEqual(r3["catalog"]["generation"], 3)

    def test_05_action_0_initial_journal(self):
        result = self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1, stop_after_actions=0)
        self.assertEqual(result.get("status"), "incomplete")
        self.assertTrue(self.journal_g1.is_file())
        j_data = json.loads(self.journal_g1.read_text(encoding="utf-8"))
        self.assertEqual(j_data.get("next_action"), 0)
        self.assertEqual(len(j_data.get("shards", [])), 0)
        self.assertFalse(self.catalog.exists())

    def test_06_action_1_stage_shard(self):
        result = self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1, stop_after_actions=1)
        self.assertEqual(result.get("status"), "incomplete")
        j_data = json.loads(self.journal_g1.read_text(encoding="utf-8"))
        self.assertEqual(j_data.get("next_action"), 1)
        self.assertEqual(len(j_data.get("shards", [])), 1)
        staging_part_a = self.catalog.parent / ".staging" / j_data["identity"] / "part-A.parquet"
        self.assertTrue(staging_part_a.is_file())

    def test_07_resume_from_action_0(self):
        self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1, stop_after_actions=0)
        result = self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1, resume=True)
        self.assertEqual(result.get("status"), "complete")
        self.assertTrue(self.catalog.is_file())

    def test_08_resume_midway(self):
        self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1, stop_after_actions=2)
        result = self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1, resume=True)
        self.assertEqual(result.get("status"), "complete")

    def test_09_stale_worker_rejection(self):
        self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1)
        self.run_generation(self.input_dir / "g2.json", self.catalog, self.journal_g2)
        # Attempt to run g2 again with an old parent or replay g1
        with self.assertRaises(ValueError):
            self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1)

    def test_10_tampered_journal_checksum_raises_value_error(self):
        self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1, stop_after_actions=1)
        raw = json.loads(self.journal_g1.read_text(encoding="utf-8"))
        raw["checksum"] = "0" * 64
        self.journal_g1.write_bytes(canonical_json(raw) + b"\n")
        with self.assertRaises(ValueError):
            self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1, resume=True)

    def test_11_tampered_parent_snapshot_raises_value_error(self):
        self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1)
        cat = json.loads(self.catalog.read_text(encoding="utf-8"))
        snap_path = self.catalog.parent / cat["snapshot_path"]
        snap_data = json.loads(snap_path.read_text(encoding="utf-8"))
        snap_data["total_rows"] = 999999
        snap_path.write_bytes(canonical_json(snap_data) + b"\n")
        with self.assertRaises(ValueError):
            self.run_generation(self.input_dir / "g2.json", self.catalog, self.journal_g2)

    def test_12_malformed_json_raises_value_error(self):
        bad_file = self.tmp / "bad.json"
        bad_file.write_text("{malformed: json", encoding="utf-8")
        with self.assertRaises(ValueError):
            self.run_generation(bad_file, self.catalog, self.journal_g1)

    def test_13_corrupt_parquet_raises_value_error(self):
        shutil.copytree(self.input_dir / "data", self.tmp / "data", dirs_exist_ok=True)
        shutil.copytree(self.input_dir / "deletes", self.tmp / "deletes", dirs_exist_ok=True)
        corrupt_job = json.loads((self.input_dir / "g1.json").read_text(encoding="utf-8"))
        bad_data_file = self.tmp / "data" / "corrupt.parquet"
        bad_data_file.write_bytes(b"not a valid parquet file")
        corrupt_job["add_data"][0]["path"] = "data/corrupt.parquet"
        corrupt_input = self.tmp / "bad_input.json"
        corrupt_input.write_bytes(canonical_json(corrupt_job) + b"\n")
        with self.assertRaises(ValueError):
            self.run_generation(corrupt_input, self.catalog, self.journal_g1)

    def test_14_duplicate_json_keys_raises_value_error(self):
        bad_json = b'{"version":1,"version":1}'
        dup_file = self.tmp / "dup.json"
        dup_file.write_bytes(bad_json)
        with self.assertRaises(ValueError):
            self.run_generation(dup_file, self.catalog, self.journal_g1)

    def test_15_negative_stop_actions_raises_value_error(self):
        with self.assertRaises(ValueError):
            self.run_generation(self.input_dir / "g1.json", self.catalog, self.journal_g1, stop_after_actions=-1)

    def test_16_delete_bounds_violation_raises_value_error(self):
        shutil.copytree(self.input_dir / "data", self.tmp / "data", dirs_exist_ok=True)
        shutil.copytree(self.input_dir / "deletes", self.tmp / "deletes", dirs_exist_ok=True)
        job = json.loads((self.input_dir / "g1.json").read_text(encoding="utf-8"))
        job["add_deletes"][0]["row_count"] = 99999
        bad_input = self.tmp / "bad_delete.json"
        bad_input.write_bytes(canonical_json(job) + b"\n")
        with self.assertRaises(ValueError):
            self.run_generation(bad_input, self.catalog, self.journal_g1)

    def test_17_cli_run(self):
        cmd = [sys.executable, "-m", "compactor", "run",
               "--input", str(self.input_dir / "g1.json"),
               "--catalog", str(self.catalog),
               "--journal", str(self.journal_g1)]
        res = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(res.returncode, 0, f"CLI error: {res.stderr}")
        data = json.loads(res.stdout)
        self.assertEqual(data.get("status"), "complete")

    def test_18_cli_resume(self):
        cmd_init = [sys.executable, "-m", "compactor", "run",
                    "--input", str(self.input_dir / "g1.json"),
                    "--catalog", str(self.catalog),
                    "--journal", str(self.journal_g1),
                    "--stop-after-actions", "1"]
        res_init = subprocess.run(cmd_init, capture_output=True, text=True)
        self.assertEqual(res_init.returncode, 0)
        cmd_resume = [sys.executable, "-m", "compactor", "resume",
                      "--input", str(self.input_dir / "g1.json"),
                      "--catalog", str(self.catalog),
                      "--journal", str(self.journal_g1)]
        res_resume = subprocess.run(cmd_resume, capture_output=True, text=True)
        self.assertEqual(res_resume.returncode, 0, f"CLI error: {res_resume.stderr}")
        data = json.loads(res_resume.stdout)
        self.assertEqual(data.get("status"), "complete")


if __name__ == "__main__":
    unittest.main()
