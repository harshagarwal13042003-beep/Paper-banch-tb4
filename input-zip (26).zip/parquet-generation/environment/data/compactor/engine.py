"""Generation-aware Parquet compactor starter.

This implementation contains state, projection, delete, and publication faults.
Repair its observable behavior using the public contract.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq

TYPES = {"int64": pa.int64(), "float64": pa.float64(), "string": pa.string()}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(canonical(value) + b"\n")


def schema_for(fields):
    return pa.schema([
        pa.field(field["name"], TYPES[field["type"]], nullable=field["nullable"],
                 metadata={b"PARQUET:field_id": str(field["id"]).encode()})
        for field in fields
    ])


def journal_for(job, identity, catalog, action, shards):
    body = {"version": 1, "identity": identity, "parent_identity": job["parent_identity"],
            "generation": job["generation"], "catalog_path": str(catalog),
            "next_action": action, "shards": shards,
            "total_rows": sum(shard["row_count"] for shard in shards)}
    return {**body, "checksum": digest(canonical(body))}


def shard_for(root, out_dir, identity, partition, fields, data, deletes):
    positions = {}
    contributing = []
    for item in deletes:
        if item["partition"] == partition:
            for record in pq.read_table(root / item["path"]).to_pylist():
                positions.setdefault(record["file_path"], set()).add(record["pos"])
            contributing.append(item["path"])
    rows, lineage = [], []
    for item in data:
        if item["partition"] != partition:
            continue
        source = pq.read_table(root / item["path"]).to_pylist()
        gone = positions.get(item["path"], set())
        for i, record in enumerate(source):
            if i not in gone:
                rows.append({f["name"]: record.get(f["name"], f["default"]) for f in fields})
        lineage.append({"data_file": item["path"], "input_rows": len(source),
                        "deleted_rows": len(gone), "retained_rows": len(source) - len(gone)})
    stage = out_dir / ".staging" / identity / f"part-{partition}.parquet"
    stage.parent.mkdir(parents=True, exist_ok=True)
    pq.write_table(pa.Table.from_pylist(rows, schema=schema_for(fields)), stage,
                   compression="NONE", use_dictionary=False, write_statistics=False)
    return {"partition": partition, "path": f"shards/{identity}/part-{partition}.parquet",
            "row_count": len(rows), "row_digest": digest(canonical(rows)),
            "lineage": lineage, "delete_files": contributing}


def run_generation(input_path, catalog_path, journal_path, stop_after_actions=None, resume=False):
    input_path = Path(input_path).resolve()
    catalog_path = Path(catalog_path).resolve()
    journal_path = Path(journal_path).resolve()
    if stop_after_actions is not None and (
            type(stop_after_actions) is not int or stop_after_actions < 0):
        raise ValueError("stop_after_actions must be a nonnegative integer")
    job = read_json(input_path)
    root = input_path.parent
    parent = None
    if catalog_path.exists():
        previous = read_json(catalog_path)
        parent_file = catalog_path.parent / previous["snapshot_path"]
        parent = read_json(parent_file)
    data = [x for x in (parent["data_files"] if parent else [])
            if x["path"] not in job["remove_data"]] + job["add_data"]
    deletes = [x for x in (parent["delete_files"] if parent else [])
               if x["path"] not in job["remove_deletes"]] + job["add_deletes"]
    schemas = dict(parent["schemas"]) if parent else {}
    schemas[str(job["schema"]["id"])] = job["schema"]["fields"]
    identity = digest(canonical({
        "job": job,
        "parent_snapshot_sha256": digest(parent_file.read_bytes()) if parent else None,
        "data_sha256": [digest((root / x["path"]).read_bytes()) for x in data],
        "delete_sha256": [digest((root / x["path"]).read_bytes()) for x in deletes]}))
    partitions = sorted({x["partition"] for x in data + deletes})
    fields = job["schema"]["fields"]
    if resume:
        journal = read_json(journal_path)
        action, shards = journal["next_action"], list(journal["shards"])
    else:
        if journal_path.exists():
            raise ValueError("journal exists")
        action, shards = 0, []
        journal = journal_for(job, identity, catalog_path, action, shards)
        write_json(journal_path, journal)
    limit = len(partitions) + 2
    end = limit if stop_after_actions is None else min(limit, action + stop_after_actions)
    for step in range(action + 1, end + 1):
        if step <= len(partitions):
            shards.append(shard_for(root, catalog_path.parent, identity,
                                    partitions[step - 1], fields, data, deletes))
        elif step == len(partitions) + 1:
            target = catalog_path.parent / "shards" / identity
            target.mkdir(parents=True, exist_ok=True)
            for shard in shards:
                name = Path(shard["path"]).name
                os.replace(catalog_path.parent / ".staging" / identity / name, target / name)
        else:
            all_rows = []
            for shard in shards:
                all_rows.extend(pq.read_table(catalog_path.parent / shard["path"]).to_pylist())
            snapshot = {
                "version": 1, "generation": job["generation"],
                "snapshot_id": job["snapshot_id"], "identity": identity,
                "parent_identity": job["parent_identity"], "input_root": str(root),
                "schemas": schemas, "current_schema_id": job["schema"]["id"],
                "data_files": data, "delete_files": deletes, "fields": fields,
                "shards": shards, "total_rows": len(all_rows),
                "total_row_digest": digest(canonical(all_rows))}
            snapshot_path = catalog_path.parent / "snapshots" / f"{identity}.json"
            write_json(snapshot_path, snapshot)
            catalog = {"version": 1, "generation": job["generation"],
                       "identity": identity, "snapshot_path": f"snapshots/{identity}.json",
                       "snapshot_sha256": digest(snapshot_path.read_bytes())}
            write_json(catalog_path, catalog)
        journal = journal_for(job, identity, catalog_path, step, shards)
        write_json(journal_path, journal)
    if end == limit:
        return {"status": "complete", "journal": journal,
                "catalog": catalog, "snapshot": snapshot}
    return {"status": "incomplete", "journal": journal}
