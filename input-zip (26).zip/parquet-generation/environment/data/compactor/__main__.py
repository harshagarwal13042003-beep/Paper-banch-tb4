"""Command line interface for the generation runner."""
from __future__ import annotations

import argparse
import json
import sys

from .engine import run_generation


def main(argv=None):
    parser = argparse.ArgumentParser(prog="python -m compactor")
    modes = parser.add_subparsers(dest="mode", required=True)
    for name in ("run", "resume"):
        command = modes.add_parser(name)
        command.add_argument("--input", required=True)
        command.add_argument("--catalog", required=True)
        command.add_argument("--journal", required=True)
        command.add_argument("--stop-after-actions", type=int)
    args = parser.parse_args(argv)
    try:
        result = run_generation(args.input, args.catalog, args.journal,
                                stop_after_actions=args.stop_after_actions,
                                resume=args.mode == "resume")
    except (ValueError, OSError, KeyError) as exc:
        print(f"generation failed: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True, separators=(",", ":"),
                     ensure_ascii=False, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
