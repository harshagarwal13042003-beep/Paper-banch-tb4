"""Public generation-aware local Parquet compaction API."""
from .engine import run_generation

__all__ = ["run_generation"]
