"""Shared validation, Parquet, and atomic I/O helpers for generation repair."""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import tempfile

import pyarrow as pa
import pyarrow.parquet as pq


I64_MIN = -(1 << 63)
I64_MAX = (1 << 63) - 1
ID_MAX = (1 << 31) - 1
PARTITION = re.compile(r"[A-Za-z0-9_-]+\Z")
HEX = re.compile(r"[0-9a-f]{64}\Z")
FIELD_TYPES = {"int64": pa.int64(), "float64": pa.float64(), "string": pa.string()}


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def _parse_json(data):
    try:
        return json.loads(data.decode("utf-8"), object_pairs_hook=_unique_object,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError("non-finite JSON")))
    except (UnicodeError, json.JSONDecodeError, TypeError) as exc:
        raise ValueError("invalid UTF-8 JSON") from exc


def _keys(value, wanted, label):
    if not isinstance(value, dict) or set(value) != set(wanted):
        raise ValueError(f"invalid {label} keys")
    return value


def _i64(value, label, *, nonnegative=False):
    if type(value) is not int or not I64_MIN <= value <= I64_MAX or (nonnegative and value < 0):
        raise ValueError(f"invalid {label}")
    return value


def _add_i64(left, right, label):
    return _i64(left + right, label, nonnegative=True)


def _field_value(value, field, label):
    if value is None:
        if not field["nullable"]:
            raise ValueError(f"null {label}")
        return None
    if field["type"] == "int64":
        return _i64(value, label)
    if field["type"] == "float64":
        if type(value) not in (int, float):
            raise ValueError(f"invalid {label}")
        try:
            number = float(value)
        except (ValueError, OverflowError) as exc:
            raise ValueError(f"invalid {label}") from exc
        if not math.isfinite(number):
            raise ValueError(f"non-finite {label}")
        return number
    if type(value) is not str:
        raise ValueError(f"invalid {label}")
    return value


def _schema_fields(value, label):
    if not isinstance(value, list) or not value:
        raise ValueError(f"invalid {label}")
    seen_ids, seen_names = set(), set()
    for field in value:
        _keys(field, ("id", "name", "type", "nullable", "default"), "schema field")
        if type(field["id"]) is not int or not 0 < field["id"] <= ID_MAX:
            raise ValueError("invalid field ID")
        if type(field["name"]) is not str or not field["name"]:
            raise ValueError("invalid field name")
        if type(field["type"]) is not str or field["type"] not in FIELD_TYPES or type(field["nullable"]) is not bool:
            raise ValueError("invalid field type or nullability")
        if field["id"] in seen_ids or field["name"] in seen_names:
            raise ValueError("duplicate schema field")
        seen_ids.add(field["id"])
        seen_names.add(field["name"])
        if field["default"] is not None:
            _field_value(field["default"], field, "default")
    return value


def _arrow_schema(fields):
    return pa.schema([
        pa.field(f["name"], FIELD_TYPES[f["type"]], nullable=f["nullable"],
                 metadata={b"PARQUET:field_id": str(f["id"]).encode("ascii")})
        for f in fields
    ])


def _validate_arrow_schema(actual, fields, label, *, field_ids=True):
    if len(actual) != len(fields):
        raise ValueError(f"wrong {label} column count")
    for got, expected in zip(actual, fields):
        if (got.name != expected["name"] or got.type != FIELD_TYPES[expected["type"]]
                or got.nullable != expected["nullable"]):
            raise ValueError(f"wrong {label} schema")
        if field_ids and (got.metadata or {}).get(b"PARQUET:field_id") != str(expected["id"]).encode("ascii"):
            raise ValueError(f"wrong {label} field ID")


def _no_symlinks(path):
    for part in (path, *path.parents):
        if part.is_symlink():
            raise ValueError("symlink path")


def _file_path(root, relative, kind):
    if type(relative) is not str or "\\" in relative or not relative.endswith(".parquet"):
        raise ValueError("invalid Parquet path")
    pure = PurePosixPath(relative)
    if (pure.is_absolute() or len(pure.parts) < 2 or pure.parts[0] != kind
            or any(part in ("", ".", "..") for part in relative.split("/"))):
        raise ValueError("unsafe Parquet path")
    path = root.joinpath(*pure.parts)
    _no_symlinks(path)
    if not path.is_file():
        raise ValueError("missing Parquet file")
    return path


def _read_parquet(path):
    try:
        return pq.read_table(path, use_threads=False)
    except Exception as exc:
        raise ValueError("invalid Parquet file") from exc


def _expected(current, data, deletes, identity):
    by_path = {entry["path"]: (entry, rows) for entry, rows in data}
    deleted = {path: set() for path in by_path}
    delete_files_by_partition = {}
    for deletion, records in deletes:
        eligible = False
        for record in records:
            target = by_path.get(record["file_path"])
            if target is None:
                raise ValueError("delete references missing data file")
            source, rows = target
            if deletion["partition"] != source["partition"]:
                raise ValueError("delete partition mismatch")
            if record["pos"] >= len(rows):
                raise ValueError("delete position out of range")
            if deletion["sequence"] >= source["sequence"]:
                deleted[source["path"]].add(record["pos"])
                eligible = True
        if eligible:
            delete_files_by_partition.setdefault(deletion["partition"], []).append(deletion["path"])
    partitions = sorted({entry["partition"] for entry, _ in data} |
                        {entry["partition"] for entry, _ in deletes})
    shard_rows, shard_info, all_rows, total = {}, [], [], 0
    for partition in partitions:
        rows_out, lineage = [], []
        for source, rows in data:
            if source["partition"] != partition:
                continue
            hits = deleted[source["path"]]
            for pos, row in enumerate(rows):
                if pos in hits:
                    continue
                projected = {}
                for field in current:
                    value = row.get(field["id"], field["default"])
                    projected[field["name"]] = _field_value(value, field, "projected value")
                rows_out.append(projected)
            lineage.append({"data_file": source["path"], "input_rows": len(rows),
                            "deleted_rows": len(hits), "retained_rows": len(rows) - len(hits)})
        total = _add_i64(total, len(rows_out), "total rows")
        relative = f"shards/{identity}/part-{partition}.parquet"
        shard_info.append({"partition": partition, "path": relative, "row_count": len(rows_out),
                           "row_digest": _sha(_canonical(rows_out)), "lineage": lineage,
                           "delete_files": delete_files_by_partition.get(partition, [])})
        shard_rows[partition] = rows_out
        all_rows.extend(rows_out)
    return partitions, shard_rows, shard_info, total, _sha(_canonical(all_rows))


def _check_shard(path, rows, schema):
    _no_symlinks(path)
    if not path.is_file():
        raise ValueError("missing staged shard")
    table = _read_parquet(path)
    if len(table.schema) != len(schema) or any(
        not got.equals(expected, check_metadata=True)
        for got, expected in zip(table.schema, schema)
    ):
        raise ValueError("wrong staged shard schema")
    if _canonical(table.to_pylist()) != _canonical(rows):
        raise ValueError("altered staged shard")


def _check_shard_dir(directory, partitions, rows, schema):
    _no_symlinks(directory)
    if not directory.is_dir():
        raise ValueError("missing shard directory")
    expected = {f"part-{partition}.parquet" for partition in partitions}
    if {member.name for member in directory.iterdir()} != expected:
        raise ValueError("unexpected shard directory content")
    for partition in partitions:
        _check_shard(directory / f"part-{partition}.parquet", rows[partition], schema)


def _atomic_bytes(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".tmp-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _write_shard(path, rows, schema):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".part-", suffix=".parquet", dir=path.parent)
    os.close(fd)
    try:
        table = pa.Table.from_pylist(rows, schema=schema)
        pq.write_table(table, temporary, compression="NONE", use_dictionary=False,
                       write_statistics=False, version="2.6")
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


