"""Install the reference repair into the agent-visible starter package."""
from pathlib import Path
import shutil
import sys


def main():
    source = Path(__file__).resolve().parent
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/app/workspace/compactor")
    target.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source / "reference.py", target / "engine.py")
    shutil.copyfile(source / "generation.py", target / "generation.py")
    shutil.copyfile(source / "cli_generation.py", target / "__main__.py")
    (target / "__init__.py").write_text(
        '"""Public generation-aware Parquet compaction API."""\n'
        'from .generation import run_generation\n'
        '__all__ = ["run_generation"]\n', encoding="utf-8")


if __name__ == "__main__":
    main()
