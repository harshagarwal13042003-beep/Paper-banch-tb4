"""Generation-aware reference implementation installed beside engine.py."""
from __future__ import annotations

import os
from pathlib import Path

import pyarrow as pa

from .engine import (_canonical, _sha, _parse_json, _keys, _i64, _add_i64,
                     _schema_fields, _arrow_schema, _validate_arrow_schema,
                     _file_path, _read_parquet, _field_value, _no_symlinks,
                     _atomic_bytes, _write_shard, _check_shard_dir, _check_shard,
                     _expected, HEX, PARTITION, I64_MAX)


JOB_KEYS = ("version", "generation", "snapshot_id", "parent_identity", "schema",
            "remove_data", "add_data", "remove_deletes", "add_deletes")
SNAP_KEYS = ("version", "generation", "snapshot_id", "identity", "parent_identity",
             "input_root", "schemas", "current_schema_id", "data_files", "delete_files",
             "fields", "shards", "total_rows", "total_row_digest")
CAT_KEYS = ("version", "generation", "identity", "snapshot_path", "snapshot_sha256")
JOURNAL_KEYS = ("version", "identity", "parent_identity", "generation", "catalog_path",
                "next_action", "shards", "total_rows", "checksum")


def canonical_file(path, label):
    _no_symlinks(path)
    if not path.is_file():
        raise ValueError(f"missing {label}")
    raw = path.read_bytes()
    value = _parse_json(raw)
    if raw != _canonical(value) + b"\n":
        raise ValueError(f"noncanonical {label}")
    return value, raw


def valid_hash(value):
    return type(value) is str and HEX.fullmatch(value) is not None


def parse_job(path):
    _no_symlinks(path)
    if not path.is_file():
        raise ValueError("missing job")
    job = _parse_json(path.read_bytes())
    _keys(job, JOB_KEYS, "job")
    if type(job["version"]) is not int or job["version"] != 1:
        raise ValueError("unsupported job version")
    _i64(job["generation"], "generation", nonnegative=True)
    if job["generation"] == 0:
        raise ValueError("generation must be positive")
    if type(job["snapshot_id"]) is not str or not job["snapshot_id"]:
        raise ValueError("invalid snapshot ID")
    if job["generation"] == 1:
        if job["parent_identity"] is not None:
            raise ValueError("root job has parent")
    elif not valid_hash(job["parent_identity"]):
        raise ValueError("invalid parent identity")
    _keys(job["schema"], ("id", "fields"), "schema")
    _i64(job["schema"]["id"], "schema ID", nonnegative=True)
    _schema_fields(job["schema"]["fields"], "current schema")
    for key in ("remove_data", "add_data", "remove_deletes", "add_deletes"):
        if type(job[key]) is not list:
            raise ValueError("invalid job list")
    for key in ("remove_data", "remove_deletes"):
        if any(type(path) is not str for path in job[key]) or len(set(job[key])) != len(job[key]):
            raise ValueError("duplicate or invalid removal")
    if job["generation"] == 1 and (job["remove_data"] or job["remove_deletes"]):
        raise ValueError("root removal")
    return job


def parse_snapshot(path, identity, root):
    snapshot, raw = canonical_file(path, "snapshot")
    _keys(snapshot, SNAP_KEYS, "snapshot")
    if type(snapshot["version"]) is not int or snapshot["version"] != 1 or snapshot["identity"] != identity:
        raise ValueError("snapshot identity mismatch")
    _i64(snapshot["generation"], "snapshot generation", nonnegative=True)
    if snapshot["generation"] < 1 or type(snapshot["snapshot_id"]) is not str or not snapshot["snapshot_id"]:
        raise ValueError("invalid snapshot metadata")
    if snapshot["generation"] == 1:
        if snapshot["parent_identity"] is not None:
            raise ValueError("invalid root parent")
    elif not valid_hash(snapshot["parent_identity"]):
        raise ValueError("invalid snapshot parent")
    if snapshot["input_root"] != str(root):
        raise ValueError("parent input root differs")
    if type(snapshot["schemas"]) is not dict:
        raise ValueError("invalid schemas")
    current_id = _i64(snapshot["current_schema_id"], "current schema ID", nonnegative=True)
    if current_id < 1 or set(snapshot["schemas"]) != {str(i) for i in range(1, current_id + 1)}:
        raise ValueError("invalid schema history")
    historical_types = {}
    for fields in snapshot["schemas"].values():
        _schema_fields(fields, "parent schema")
        for field in fields:
            old_type = historical_types.setdefault(field["id"], field["type"])
            if old_type != field["type"]:
                raise ValueError("parent field ID changed type")
    if snapshot["fields"] != snapshot["schemas"][str(current_id)]:
        raise ValueError("inconsistent current fields")
    if type(snapshot["data_files"]) is not list or type(snapshot["delete_files"]) is not list:
        raise ValueError("invalid active lists")
    if type(snapshot["shards"]) is not list:
        raise ValueError("invalid shard list")
    _i64(snapshot["total_rows"], "parent total rows", nonnegative=True)
    if not valid_hash(snapshot["total_row_digest"]):
        raise ValueError("invalid parent row digest")
    active_data = {item.get("path") for item in snapshot["data_files"] if type(item) is dict}
    active_deletes = {item.get("path") for item in snapshot["delete_files"] if type(item) is dict}
    partitions = []
    shard_total = 0
    for shard in snapshot["shards"]:
        _keys(shard, ("partition", "path", "row_count", "row_digest", "lineage", "delete_files"), "parent shard")
        partition = shard["partition"]
        if type(partition) is not str or PARTITION.fullmatch(partition) is None:
            raise ValueError("invalid parent shard partition")
        partitions.append(partition)
        if shard["path"] != f"shards/{identity}/part-{partition}.parquet":
            raise ValueError("invalid parent shard path")
        shard_total = _add_i64(shard_total, _i64(shard["row_count"], "parent shard rows", nonnegative=True),
                               "parent total rows")
        if not valid_hash(shard["row_digest"]):
            raise ValueError("invalid parent shard digest")
        if type(shard["lineage"]) is not list or type(shard["delete_files"]) is not list:
            raise ValueError("invalid parent shard lists")
        retained_total = 0
        for item in shard["lineage"]:
            _keys(item, ("data_file", "input_rows", "deleted_rows", "retained_rows"), "lineage")
            if item["data_file"] not in active_data:
                raise ValueError("parent lineage names inactive data")
            source = _i64(item["input_rows"], "lineage input rows", nonnegative=True)
            deleted = _i64(item["deleted_rows"], "lineage deleted rows", nonnegative=True)
            retained = _i64(item["retained_rows"], "lineage retained rows", nonnegative=True)
            if deleted + retained != source:
                raise ValueError("parent lineage count mismatch")
            retained_total = _add_i64(retained_total, retained, "parent shard rows")
        if retained_total != shard["row_count"]:
            raise ValueError("parent shard/lineage mismatch")
        if any(type(path) is not str or path not in active_deletes for path in shard["delete_files"]):
            raise ValueError("parent shard names inactive delete")
    if partitions != sorted(set(partitions)) or shard_total != snapshot["total_rows"]:
        raise ValueError("parent shard order or total mismatch")
    return snapshot, raw


def parse_catalog(path, root):
    catalog, raw = canonical_file(path, "catalog")
    _keys(catalog, CAT_KEYS, "catalog")
    if type(catalog["version"]) is not int or catalog["version"] != 1 or not valid_hash(catalog["identity"]) or not valid_hash(catalog["snapshot_sha256"]):
        raise ValueError("invalid catalog")
    _i64(catalog["generation"], "catalog generation", nonnegative=True)
    identity = catalog["identity"]
    if catalog["snapshot_path"] != f"snapshots/{identity}.json":
        raise ValueError("invalid catalog snapshot path")
    snapshot, snap_raw = parse_snapshot(path.parent / "snapshots" / f"{identity}.json", identity, root)
    if _sha(snap_raw) != catalog["snapshot_sha256"] or snapshot["generation"] != catalog["generation"]:
        raise ValueError("catalog checksum or generation mismatch")
    return catalog, snapshot, snap_raw


def select_parent(job, catalog_path, root, resume):
    live = None
    if catalog_path.exists():
        live, _, _ = parse_catalog(catalog_path, root)
    if job["generation"] == 1:
        if live is not None and not resume:
            raise ValueError("root catalog already exists")
        return None, None, live
    if live is None:
        raise ValueError("missing parent catalog")
    parent_id = job["parent_identity"]
    if live["identity"] == parent_id:
        if live["generation"] + 1 != job["generation"]:
            raise ValueError("wrong generation")
        parent, raw = parse_snapshot(catalog_path.parent / "snapshots" / f"{parent_id}.json", parent_id, root)
        if _sha(raw) != live["snapshot_sha256"]:
            raise ValueError("parent hash mismatch")
        return parent, raw, live
    if resume and live["generation"] == job["generation"]:
        parent, raw = parse_snapshot(catalog_path.parent / "snapshots" / f"{parent_id}.json", parent_id, root)
        if parent["generation"] + 1 != job["generation"]:
            raise ValueError("wrong parent generation")
        return parent, raw, live
    raise ValueError("stale parent")


def active_manifest(job, parent, root):
    schemas = {} if parent is None else dict(parent["schemas"])
    wanted_id = 1 if parent is None else parent["current_schema_id"] + 1
    if job["schema"]["id"] != wanted_id:
        raise ValueError("wrong new schema ID")
    old_types = {}
    for fields in schemas.values():
        for field in fields:
            old_types.setdefault(field["id"], field["type"])
    for field in job["schema"]["fields"]:
        if field["id"] in old_types and field["type"] != old_types[field["id"]]:
            raise ValueError("field ID changed type")
    schemas[str(wanted_id)] = job["schema"]["fields"]
    data = [] if parent is None else list(parent["data_files"])
    deletes = [] if parent is None else list(parent["delete_files"])
    for remove_key, entries in (("remove_data", data), ("remove_deletes", deletes)):
        active = {item["path"] for item in entries}
        if any(path not in active for path in job[remove_key]):
            raise ValueError("removal names inactive file")
        entries[:] = [item for item in entries if item["path"] not in job[remove_key]]
    data.extend(job["add_data"])
    deletes.extend(job["add_deletes"])
    used = set()
    for is_data, entries, kind in ((True, data, "data"), (False, deletes, "deletes")):
        names = ("path", "partition", "schema_id", "sequence", "row_count", "sha256") if is_data else (
            "path", "partition", "sequence", "row_count", "sha256")
        for entry in entries:
            _keys(entry, names, "file entry")
            if type(entry["partition"]) is not str or PARTITION.fullmatch(entry["partition"]) is None:
                raise ValueError("invalid partition")
            _i64(entry["sequence"], "sequence", nonnegative=True)
            _i64(entry["row_count"], "row count", nonnegative=True)
            if not valid_hash(entry["sha256"]):
                raise ValueError("invalid file hash")
            if is_data and (type(entry["schema_id"]) is not int or str(entry["schema_id"]) not in schemas):
                raise ValueError("invalid source schema ID")
            path = _file_path(root, entry["path"], kind)
            folded = entry["path"].casefold()
            if folded in used:
                raise ValueError("duplicate active file")
            used.add(folded)
    return schemas, job["schema"]["fields"], data, deletes


def load_active(root, schemas, data, deletes):
    parsed_data, parsed_deletes, data_hashes, delete_hashes, paths = [], [], [], [], []
    for is_data, entries, destination, hashes, kind in ((True, data, parsed_data, data_hashes, "data"),
                                                       (False, deletes, parsed_deletes, delete_hashes, "deletes")):
        for entry in entries:
            path = _file_path(root, entry["path"], kind)
            paths.append(path)
            raw_hash = _sha(path.read_bytes())
            if raw_hash != entry["sha256"]:
                raise ValueError("file hash mismatch")
            hashes.append(raw_hash)
            table = _read_parquet(path)
            if table.num_rows != entry["row_count"]:
                raise ValueError("file row count mismatch")
            if is_data:
                fields = schemas[str(entry["schema_id"])]
                _validate_arrow_schema(table.schema, fields, "data")
                rows = [{field["id"]: _field_value(row[field["name"]], field, "data value")
                         for field in fields} for row in table.to_pylist()]
            else:
                fixed = [{"name": "file_path", "type": "string", "nullable": False},
                         {"name": "pos", "type": "int64", "nullable": False}]
                _validate_arrow_schema(table.schema, fixed, "delete", field_ids=False)
                rows = table.to_pylist()
                for row in rows:
                    if type(row["file_path"]) is not str:
                        raise ValueError("invalid delete target")
                    _i64(row["pos"], "delete position", nonnegative=True)
            destination.append((entry, rows))
    return parsed_data, parsed_deletes, data_hashes, delete_hashes, paths


def journal_object(identity, job, catalog_path, action, shards):
    total = 0
    for item in shards:
        total = _add_i64(total, item["row_count"], "journal rows")
    body = {"version": 1, "identity": identity, "parent_identity": job["parent_identity"],
            "generation": job["generation"], "catalog_path": str(catalog_path),
            "next_action": action, "shards": shards, "total_rows": total}
    return {**body, "checksum": _sha(_canonical(body))}


def check_journal(path, identity, job, catalog_path, partitions, rows, shards, schema, stage, final):
    existing, _ = canonical_file(path, "journal")
    _keys(existing, JOURNAL_KEYS, "journal")
    action = existing["next_action"]
    if type(action) is not int or not 0 <= action <= len(partitions) + 2:
        raise ValueError("invalid journal boundary")
    prefix = shards[:min(action, len(partitions))]
    if existing != journal_object(identity, job, catalog_path, action, prefix):
        raise ValueError("altered or stale journal")
    if action <= len(partitions):
        if action:
            _check_shard_dir(stage, partitions[:action], rows, schema)
    else:
        _check_shard_dir(final, partitions, rows, schema)
    return action


def layout(input_path, active_paths, catalog_path, journal_path, identity):
    if len({input_path, catalog_path, journal_path}) != 3:
        raise ValueError("path collision")
    stage = catalog_path.parent / ".staging" / identity
    final = catalog_path.parent / "shards" / identity
    snapshot_path = catalog_path.parent / "snapshots" / f"{identity}.json"
    for path in (input_path, catalog_path, journal_path, stage, final, snapshot_path, *active_paths):
        _no_symlinks(path)
    if any(path.is_dir() for path in (catalog_path, journal_path, snapshot_path)):
        raise ValueError("file path is a directory")
    for path in (input_path, *active_paths, catalog_path, journal_path):
        if path.is_relative_to(stage) or path.is_relative_to(final):
            raise ValueError("input/output shard collision")
    for path in (catalog_path, journal_path):
        if any(path.is_relative_to(catalog_path.parent / reserved)
               for reserved in ("snapshots", "shards", ".staging")):
            raise ValueError("path occupies immutable output area")
    if any(path in active_paths for path in (catalog_path, journal_path, snapshot_path)):
        raise ValueError("input/output file collision")
    if catalog_path == snapshot_path or journal_path == snapshot_path:
        raise ValueError("publication path collision")
    return stage, final, snapshot_path


def _run_generation(input_path, catalog_path, journal_path, stop_after_actions=None, resume=False):
    if stop_after_actions is not None:
        _i64(stop_after_actions, "stop_after_actions", nonnegative=True)
    if type(resume) is not bool:
        raise ValueError("resume must be boolean")
    input_path = Path(os.path.abspath(input_path))
    catalog_path = Path(os.path.abspath(catalog_path))
    journal_path = Path(os.path.abspath(journal_path))
    root = input_path.parent
    job = parse_job(input_path)
    parent, parent_raw, live = select_parent(job, catalog_path, root, resume)
    schemas, fields, active_data, active_deletes = active_manifest(job, parent, root)
    data, deletes, data_hashes, delete_hashes, active_paths = load_active(root, schemas, active_data, active_deletes)
    identity = _sha(_canonical({"job": job, "parent_snapshot_sha256": _sha(parent_raw) if parent_raw else None,
                                "data_sha256": data_hashes, "delete_sha256": delete_hashes}))
    partitions, rows, shards, total_rows, total_digest = _expected(fields, data, deletes, identity)
    # Include removed parent files in collision checks, even though their bytes
    # are not needed for the new generation's active-row calculation.
    mentioned = ([] if parent is None else parent["data_files"] + parent["delete_files"])
    mentioned = mentioned + job["add_data"] + job["add_deletes"]
    mentioned_paths = [root.joinpath(*entry["path"].split("/")) for entry in mentioned]
    stage, final, snapshot_path = layout(input_path, active_paths + mentioned_paths,
                                         catalog_path, journal_path, identity)
    schema = _arrow_schema(fields)
    own_committed = live is not None and live["identity"] == identity
    if live is not None and not own_committed and live["identity"] != job["parent_identity"]:
        raise ValueError("stale parent")
    if own_committed and not resume:
        raise ValueError("already committed")
    if job["generation"] == 1 and live is not None and not own_committed:
        raise ValueError("root catalog exists")
    snapshot = {"version": 1, "generation": job["generation"], "snapshot_id": job["snapshot_id"],
                "identity": identity, "parent_identity": job["parent_identity"],
                "input_root": str(root), "schemas": schemas, "current_schema_id": job["schema"]["id"],
                "data_files": active_data, "delete_files": active_deletes, "fields": fields,
                "shards": shards, "total_rows": total_rows,
                "total_row_digest": total_digest}
    snapshot_bytes = _canonical(snapshot) + b"\n"
    catalog = {"version": 1, "generation": job["generation"], "identity": identity,
               "snapshot_path": f"snapshots/{identity}.json", "snapshot_sha256": _sha(snapshot_bytes)}
    if resume:
        action = check_journal(journal_path, identity, job, catalog_path, partitions, rows, shards, schema, stage, final)
        if own_committed:
            if live != catalog or snapshot_path.read_bytes() != snapshot_bytes:
                raise ValueError("published generation differs")
            if action < len(partitions) + 2:
                action = len(partitions) + 2
                done = journal_object(identity, job, catalog_path, action, shards)
                _atomic_bytes(journal_path, _canonical(done) + b"\n")
            else:
                done = journal_object(identity, job, catalog_path, action, shards)
            return {"status": "complete", "journal": done, "catalog": catalog, "snapshot": snapshot}
        if action == len(partitions) + 2:
            raise ValueError("committed journal without catalog")
    else:
        if journal_path.exists():
            raise ValueError("journal exists")
        if stage.exists() or final.exists() or snapshot_path.exists():
            raise ValueError("identity output exists")
        action = 0
        initial = journal_object(identity, job, catalog_path, action, [])
        _atomic_bytes(journal_path, _canonical(initial) + b"\n")
    finish = len(partitions) + 2 if stop_after_actions is None else min(
        len(partitions) + 2, action + stop_after_actions)
    while action < finish:
        next_action = action + 1
        if next_action <= len(partitions):
            partition = partitions[next_action - 1]
            target = stage / f"part-{partition}.parquet"
            if target.exists():
                _check_shard(target, rows[partition], schema)
            else:
                _write_shard(target, rows[partition], schema)
        elif next_action == len(partitions) + 1:
            if final.exists():
                _check_shard_dir(final, partitions, rows, schema)
            else:
                if not stage.exists() and not partitions:
                    stage.mkdir(parents=True)
                _check_shard_dir(stage, partitions, rows, schema)
                final.parent.mkdir(parents=True, exist_ok=True)
                os.rename(stage, final)
        else:
            _check_shard_dir(final, partitions, rows, schema)
            if catalog_path.exists():
                current, _, _ = parse_catalog(catalog_path, root)
                if current["identity"] != job["parent_identity"]:
                    raise ValueError("stale parent at publication")
            elif job["parent_identity"] is not None:
                raise ValueError("parent catalog disappeared")
            if snapshot_path.exists():
                if snapshot_path.read_bytes() != snapshot_bytes:
                    raise ValueError("immutable snapshot collision")
            else:
                _atomic_bytes(snapshot_path, snapshot_bytes)
            _atomic_bytes(catalog_path, _canonical(catalog) + b"\n")
        action = next_action
        boundary = journal_object(identity, job, catalog_path, action, shards[:min(action, len(partitions))])
        _atomic_bytes(journal_path, _canonical(boundary) + b"\n")
    journal = journal_object(identity, job, catalog_path, action, shards[:min(action, len(partitions))])
    if action == len(partitions) + 2:
        return {"status": "complete", "journal": journal, "catalog": catalog, "snapshot": snapshot}
    return {"status": "incomplete", "journal": journal}


def run_generation(input_path, catalog_path, journal_path, stop_after_actions=None, resume=False):
    """Public API: convert malformed Python/JSON values into validation errors."""
    try:
        return _run_generation(input_path, catalog_path, journal_path,
                               stop_after_actions=stop_after_actions, resume=resume)
    except Exception as exc:
        if isinstance(exc, ValueError) and type(exc) is ValueError:
            raise
        raise ValueError(f"invalid generation input or state: {exc}") from exc
