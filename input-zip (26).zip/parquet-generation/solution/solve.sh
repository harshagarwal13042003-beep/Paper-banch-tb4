#!/bin/sh
set -eu
python /solution/solve.py
PYTHONPATH=/app/workspace python -m compactor run --input /app/input/g1.json --catalog /app/output/catalog.json --journal /app/state/g1.json
